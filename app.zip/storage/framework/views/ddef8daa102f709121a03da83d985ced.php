

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($artikel->title); ?></h1>
    <img src="<?php echo e(asset('storage/' . $artikel->image)); ?>" alt="<?php echo e($artikel->title); ?>" class="img-fluid">
    <p><?php echo $artikel->description; ?></p>
    <a href="/artikels" class="btn btn-secondary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\JOBSS\pt-sia\resources\views/artikel/show.blade.php ENDPATH**/ ?>