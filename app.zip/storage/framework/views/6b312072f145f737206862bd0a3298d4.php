

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top:30vw;">
    <h1 class="text-center my-4">Daftar Artikel</h1>

    <!-- Form Filter Kategori -->
    <form action="<?php echo e(route('artikel.index')); ?>" method="GET" class="mb-4">
        <div class="row">
            <div class="col-md-4">
                <select name="kategori_id" class="form-control" onchange="this.form.submit()">
                    <option value="">Semua Kategori</option>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kategori->id); ?>" <?php echo e(request('kategori_id') == $kategori->id ? 'selected' : ''); ?>>
                            <?php echo e($kategori->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </form>
    
    <!-- List Artikel -->
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo e(asset('storage/' . $artikel->image)); ?>" class="card-img-top" alt="<?php echo e($artikel->title); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($artikel->title); ?></h5>
                        <p class="card-text"><?php echo Str::limit(strip_tags($artikel->description), 100); ?></p>
                        <a href="artikel/<?php echo e($artikel->slug); ?>" class="btn btn-primary">Baca Selengkapnya</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-md-12 text-center">
                <p>Tidak ada artikel tersedia untuk kategori ini.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\JOBSS\pt-sia\resources\views/artikel/index.blade.php ENDPATH**/ ?>