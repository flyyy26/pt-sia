

<?php $__env->startSection('content'); ?>
<div class="banner_page" style="background-image: url(../images/bg_artikel.png);">
    <div class="heading_page">
        <h1>News & Articles</h1>
        <h2>News & Articles</h2>
    </div>
    <p>Temukan berbagai informasi terbaru, berita terkini, <br/>dan artikel menarik seputar topik yang Anda minati.</p>
    <div class="divider_bottom_normal"></div>
</div>
<div class="container_page">
    <div class="artikel_heading">
        <h1>Daftar Artikel</h1>

        <!-- Form Filter Kategori -->
        <form action="<?php echo e(route('news-articles.index')); ?>" method="GET" class="mb-4">
            <div class="row">
                <div class="select_layout">
                    <select name="kategori_id" class="form-control" onchange="this.form.submit()">
                        <option value="">Semua Kategori</option>
                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kategori->id); ?>" <?php echo e(request('kategori_id') == $kategori->id ? 'selected' : ''); ?>>
                                <?php echo e($kategori->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <iconify-icon icon="tabler:chevron-down"></iconify-icon>
                </div>
            </div>
        </form>
    </div>
    
    <!-- List Artikel -->
    <div class="container_artikel">
        <div class="list_artikel">
            <?php $__empty_1 = true; $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="artikel_box">
                    <div class="artikel_card">
                        <div class="artikel_card_image">
                            <a href="news-articles/<?php echo e($artikel->slug); ?>"><img src="<?php echo e(asset('storage/' . $artikel->image)); ?>" alt="<?php echo e($artikel->title); ?>"></a>
                        </div>
                        <div class="card_body">
                            <a href="news-articles/<?php echo e($artikel->slug); ?>">
                                <h5 class="card-title"><?php echo e($artikel->title); ?></h5>
                            </a>
                            <p class="card-text"><?php echo Str::limit(strip_tags($artikel->description), 60); ?></p>
                            <a href="news-articles/<?php echo e($artikel->slug); ?>"><button>Baca Selengkapnya</button></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-md-12 text-center">
                    <p>Tidak ada artikel tersedia untuk kategori ini.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
    </div>
    <?php if($artikels->hasPages()): ?>
        <div class="pagination">
            <ul class="pagination-list">
                <?php if($artikels->onFirstPage()): ?>
                    <li class="pagination_box"><iconify-icon icon="material-symbols:chevron-left-rounded"></iconify-icon></li>
                <?php else: ?>
                    <li><a href="<?php echo e($artikels->previousPageUrl()); ?>" rel="prev" class="pagination_box"><iconify-icon icon="material-symbols:chevron-left-rounded"></iconify-icon></a></li>
                <?php endif; ?>

                <?php $__currentLoopData = $artikels->links()->elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $artikels->currentPage()): ?>
                        <li class="active"><span><?php echo e($page); ?></span></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($artikels->hasMorePages()): ?>
                    <li><a href="<?php echo e($artikels->nextPageUrl()); ?>" class="pagination_box" rel="next"><iconify-icon icon="material-symbols:chevron-right-rounded"></iconify-icon></a></li>
                <?php else: ?>
                    <li class="pagination_box"><iconify-icon icon="material-symbols:chevron-right-rounded"></iconify-icon></li>
                <?php endif; ?>
            </ul>
        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\JOBSS\pt-sia\resources\views/news-articles/index.blade.php ENDPATH**/ ?>