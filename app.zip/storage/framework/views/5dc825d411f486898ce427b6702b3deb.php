

<?php $__env->startSection('content'); ?>

<div class="banner_page" style="background-image: url(../images/faq_banner.png);">
    <div class="heading_page">
        <h1>FAQS</h1>
        <h2>FAQS</h2>
    </div>
    <p>Temukan jawaban atas pertanyaan yang sering <br/>diajukan tentang layanan dan produk kami.</p>
    <div class="divider_bottom_normal"></div>
</div>
<div class="faq-container">
    <div class="faq_layout">
        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="faq-item">
                <button class="faq-question" onclick="toggleAnswer(<?php echo e($index); ?>)">
                    <?php echo e($faq->question); ?> <span class="arrow"><iconify-icon icon="majesticons:chevron-down-line"></iconify-icon></span>
                </button>
                <div class="faq-answer" id="answer-<?php echo e($index); ?>">
                    <p><?php echo e($faq->answer); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="faq_contact">
    <div class="faq_contact_layout">
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\JOBSS\pt-sia\resources\views/faq.blade.php ENDPATH**/ ?>