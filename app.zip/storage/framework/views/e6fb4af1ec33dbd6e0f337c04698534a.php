

<?php $__env->startSection('content'); ?>
<div class="container_detail_artikel">
    <div class="detail_artikel_img">
        <img src="<?php echo e(asset('storage/' . $artikel->image)); ?>" alt="<?php echo e($artikel->title); ?>">
        <div class="divider_bottom_normal"></div>
    </div>
    <div class="container_container_artikel">
        <div class="detail_artikel_heading">
            <h1><?php echo e($artikel->title); ?></h1>
            <span>Posted By : <?php echo e($artikel->author->name); ?> / On : <?php echo e($artikel->created_at->format('d F Y')); ?> / In : <?php echo e($kategori->name); ?></span>
        </div>
        <div class="detail_artikel_content">
            <?php echo $artikel->description; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\JOBSS\pt-sia\resources\views/news-articles/show.blade.php ENDPATH**/ ?>