

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-center my-4">Daftar Artikel</h1>
    
    <div class="row">
        <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo e(asset('storage/' . $artikel->image)); ?>" class="card-img-top" alt="<?php echo e($artikel->title); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($artikel->title); ?></h5>
                        <p class="card-text"><?php echo Str::limit(strip_tags($artikel->description), 100); ?></p>
                        <a href="#" class="btn btn-primary">Baca Selengkapnya</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\JOBSS\pt-sia\resources\views/artikel.blade.php ENDPATH**/ ?>