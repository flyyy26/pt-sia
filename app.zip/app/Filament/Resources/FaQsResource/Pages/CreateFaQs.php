<?php

namespace App\Filament\Resources\FaQsResource\Pages;

use App\Filament\Resources\FaQsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFaQs extends CreateRecord
{
    protected static string $resource = FaQsResource::class;
}
